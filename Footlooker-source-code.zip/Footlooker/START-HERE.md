# Footlooker source code

This ZIP contains the existing Footlooker website source, including the public directory, creator browsing experience, admin interface, API routes, styles, images, database schema and migration, and dependency lockfile.

## Start here

- `public/site.html`: the main website interface and browser interactions.
- `public/admin.html`: the admin interface for creating and editing models.
- `app/api/`: the server endpoints for login and model records.
- `app/admin-auth.ts`: admin authorization.
- `public/creators.webp`: the creator image asset.
- `README.md`: the original technical setup guide.

This is a full application. Double-clicking an HTML file can preview parts of its appearance, but login and database features require its server and database.

## Local development

Install Node.js 22.13.0 or newer. Unzip the project, open a terminal in its folder, then run:

```
npm run install:ci
npm run build
```

Follow the original README's Local D1 migrations section to apply `drizzle/0000_quick_redwing.sql` to the local `DB` database. Then run:

```
npm run dev
```

Open the local address printed by the development server.

## Admin and hosting configuration

The original application uses Cloudflare Workers, D1 (binding `DB`), and Sites identity headers. The admin login requires `ADMIN_PASSWORD` and `ADMIN_SESSION_SECRET` runtime secrets, plus the configured owner's authenticated email. These runtime secrets are not in this ZIP. The password fields in the frontend are backed by server authorization.

Running this application on a different host requires equivalent database bindings and trusted identity handling. Do not accept authentication headers supplied directly by visitors. The original README describes the development identity simulation; the admin owner check may need configuration for your local development identity.

The existing `.openai/hosting.json` identifies the original Site. Creating a separate deployment requires that deployment's own configuration.

## Contents and scope

This is a source-code export, not a backup of production data. Live database records, hosted runtime secrets, Git history, installed dependencies, generated build output, and build caches are not included. Dependencies are installed from `package-lock.json`.

Source revision: 762eae7228c9f30914436f97ad5becf38c36eb4a
