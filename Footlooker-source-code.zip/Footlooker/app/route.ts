// @ts-ignore Vite bundles the site document as text.
import site from '../public/site.html?raw';
export function GET() { return new Response(site, {headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store'}}); }
