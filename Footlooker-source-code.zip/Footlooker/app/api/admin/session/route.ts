import { authorized, clearCookie, login, mutationAllowed } from '../../../admin-auth';
export async function GET(req:Request){return Response.json({authenticated:await authorized(req)});}
export async function POST(req:Request){let body;try{body=await req.json()}catch{return Response.json({error:'Invalid request'},{status:400})}const cookie=await login(req,body as {username?:string,password?:string});if(!cookie)return Response.json({error:'Invalid credentials or access denied'},{status:401});return Response.json({authenticated:true},{headers:{'set-cookie':cookie}});}
export async function DELETE(req:Request){if(!mutationAllowed(req))return Response.json({error:'Invalid request'},{status:403});return Response.json({authenticated:false},{headers:{'set-cookie':clearCookie()}});}
