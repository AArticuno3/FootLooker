import { env } from 'cloudflare:workers';
const ownerEmail = 'spookiestories172@gmail.com';
const ownerId = 'owner';
const userName = 'admin@footlooker';
const cookieName = 'footlooker_admin';
const enc = new TextEncoder();
function owner(req: Request) { return req.headers.get('oai-authenticated-user-email')?.toLowerCase() === ownerEmail; }
function secret() { return (env as unknown as {ADMIN_SESSION_SECRET?:string}).ADMIN_SESSION_SECRET || ''; }
function password() { return (env as unknown as {ADMIN_PASSWORD?:string}).ADMIN_PASSWORD || ''; }
function hex(bytes: ArrayBuffer) { return [...new Uint8Array(bytes)].map(x=>x.toString(16).padStart(2,'0')).join(''); }
async function sign(value:string) {const key=await crypto.subtle.importKey('raw',enc.encode(secret()),{name:'HMAC',hash:'SHA-256'},false,['sign']);return hex(await crypto.subtle.sign('HMAC',key,enc.encode(value)));}
function equal(a:string,b:string) {if(a.length!==b.length)return false;let d=0;for(let i=0;i<a.length;i++)d|=a.charCodeAt(i)^b.charCodeAt(i);return d===0;}
function sameOrigin(req:Request) {const origin=req.headers.get('origin');return !!origin && origin===new URL(req.url).origin;}
export async function login(req:Request, input:{username?:string,password?:string}) {if(!owner(req)||!secret()||!password()||!sameOrigin(req))return null;if(input.username!==userName||!equal(input.password||'',password()))return null;const expiry=Date.now()+7*86400000;const data=`${ownerId}.${expiry}`;return `${cookieName}=${encodeURIComponent(data+'.'+await sign(data))}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=604800`;}
export async function authorized(req:Request) {if(!owner(req)||!secret())return false;const value=req.headers.get('cookie')?.split('; ').find(x=>x.startsWith(cookieName+'='))?.split('=')[1];if(!value)return false;let decoded;try{decoded=decodeURIComponent(value)}catch{return false}const parts=decoded.split('.');if(parts.length!==3||parts[0]!==ownerId||Number(parts[1])<Date.now())return false;const data=parts[0]+'.'+parts[1];return equal(parts[2],await sign(data));}
export function clearCookie(){return `${cookieName}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;}
export function mutationAllowed(req:Request){return sameOrigin(req);}
