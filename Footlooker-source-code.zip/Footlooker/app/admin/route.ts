// @ts-ignore Vite bundles the admin document as text.
import page from '../../public/admin.html?raw';
export function GET() { return new Response(page, {headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store'}}); }
