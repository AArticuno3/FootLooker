import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core';

export const models = sqliteTable('models', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description').notNull(),
  bio: text('bio').notNull(),
  tags: text('tags').notNull(),
  imageUrl: text('image_url').notNull().default(''),
  bannerUrl: text('banner_url').notNull().default(''),
  gallery: text('gallery').notNull().default('[]'),
  links: text('links').notNull().default('[]'),
  featured: integer('featured', {mode:'boolean'}).notNull().default(false),
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
});
